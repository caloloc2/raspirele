package com.nibemi.raspirele;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    Button cerrar, guardar;
    Switch relay1, relay2;
    EditText tiempo, ip;
    WebService web = new WebService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cerrar = (Button)findViewById(R.id.cerrar);
        relay1 = (Switch)findViewById(R.id.switch1);
        relay2 = (Switch)findViewById(R.id.switch2);
        tiempo = (EditText)findViewById(R.id.tiempo);
        ip = (EditText)findViewById(R.id.ip);
        guardar = (Button)findViewById(R.id.guardar_hora);

        relay1.setChecked(false);
        relay2.setChecked(false);

        relay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Boolean estado = relay1.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {
                        String host = ip.getText().toString();

                        final String datos = web.Reles(host, 1, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);
                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast toast1 = Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT);

                                            toast1.show();
                                        }
                                    }


                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        relay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Boolean estado = relay2.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {
                        String host = ip.getText().toString();

                        final String datos = web.Reles(host, 2, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);
                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast toast1 = Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT);

                                            toast1.show();
                                        }
                                    }


                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String hora = tiempo.getText().toString();

                Thread tr = new Thread(){
                    @Override
                    public void run() {
                        String host = ip.getText().toString();

                        final String datos = web.Configurar_Hora(host,  hora);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);
                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast toast1 = Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT);

                                            toast1.show();
                                        }
                                    }


                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });
    }
}
